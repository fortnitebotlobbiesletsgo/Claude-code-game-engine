# Visual fidelity standards

- Establish a coherent art direction before producing assets or materials: reference, palette, value structure, material language, camera language, and readability targets.
- Prefer physically plausible lighting and material response where the target renderer supports it; stylization is a deliberate art-direction choice, not an accidental shortcut.
- Build lighting in layers: key, fill, practicals, atmosphere, and controlled post-processing. Avoid using bloom, fog, or color grading to conceal weak composition.
- Use high-frequency detail selectively. Preserve silhouette, focal hierarchy, negative space, and gameplay readability at the actual camera distance.
- Define scalable quality tiers. Never assume Lumen, ray tracing, high-end GI, or expensive screen-space effects are available on every target.
- Use real project APIs and version-aware settings. Mark engine-version assumptions and never invent plugin names or asset paths.
- Validate with representative screenshots and profiling captures on target hardware. Visual quality is not a substitute for frame-time budgets.
