# Game feel and polish

- Every interaction needs a clear input-to-feedback chain: anticipation, action, impact, recovery, and readable state change.
- Tune acceleration, deceleration, input buffering, coyote time, camera response, and animation transitions against the intended genre.
- Use layered feedback: animation, sound, particles, camera, UI, and haptics where supported. Each layer should reinforce rather than compete.
- Keep hit-stop, shake, flashes, and screen distortion restrained, configurable, and accessible.
- Provide reduced-motion and effects-intensity options for players who need them.
- Effects must communicate gameplay state. Do not obscure hazards, aiming, UI text, or critical silhouettes.
- Measure responsiveness at realistic frame rates and input latency; do not tune solely by watching editor previews.
