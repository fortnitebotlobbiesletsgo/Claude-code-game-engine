# Game architecture patterns

- Separate domain/gameplay rules from engine-facing presentation and infrastructure where practical.
- Prefer composition, explicit ownership, small interfaces, and data-driven configuration over deep inheritance and global mutable state.
- Keep gameplay state authoritative and deterministic where networking, replay, or testing requires it.
- Make lifecycle, threading, resource ownership, save compatibility, and failure behavior explicit.
- Use event-driven communication for decoupled systems, but avoid unbounded event buses and hidden dependencies.
- Design systems around measurable budgets: CPU, GPU, memory, disk, bandwidth, draw calls, and load time.
- Add tests for pure logic; use engine integration tests for lifecycle and rendering behavior that cannot be validated in isolation.
- Generated code must include file paths, dependencies, setup assumptions, and a verification command.
