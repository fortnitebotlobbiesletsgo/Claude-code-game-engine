import { describe, expect, it } from "vitest";
import { appendWithMarker, replaceUnique } from "../src/utils/CodePatcher.js";

describe("CodePatcher", () => {
  it("replaces one unique target", () => {
    expect(replaceUnique("const a = 1;", "1", "2")).toBe("const a = 2;");
  });
  it("rejects ambiguous targets", () => {
    expect(() => replaceUnique("x+x", "x", "y")).toThrow(/ambiguous/);
  });
  it("rejects missing targets", () => {
    expect(() => replaceUnique("abc", "z", "y")).toThrow(/not found/);
  });
  it("appends a marker once", () => {
    expect(appendWithMarker("base", "// generated", "hello")).toContain("// generated\nhello");
    expect(() => appendWithMarker("// generated", "// generated", "hello")).toThrow(/already exists/);
  });
});
