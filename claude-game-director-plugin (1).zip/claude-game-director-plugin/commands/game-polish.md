---
description: Improve the visual fidelity and game feel of a selected scene or mechanic.
---

Inspect the target scene/mechanic and engine version. Produce a concise art-direction and feedback plan, then implement only the changes requested. Preserve gameplay readability, accessibility and performance. Prefer motivated lighting, coherent material response, responsive animation/audio/VFX timing and scalable quality settings. Run available checks and clearly separate implemented changes from suggestions requiring editor validation.
