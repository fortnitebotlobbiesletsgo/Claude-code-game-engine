---
description: Implement a requested game feature end-to-end with engine-aware checks.
---

Implement the feature described by the user in the current game project.

Inspect the engine/version and repository state first. Identify the smallest coherent set of files, preserve user changes, implement the feature, add/update tests where practical, run the actual build/test command, and report results. Ask before destructive edits, asset deletion, project-wide migrations or expensive operations. Do not claim success for checks that were not run.
