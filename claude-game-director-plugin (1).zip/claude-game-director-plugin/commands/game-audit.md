---
description: Audit the current game project for architecture, visuals, gameplay feel, performance and build risks.
---

Run a read-only first-pass audit of the current repository.

1. Detect engine, exact version, render pipeline, platforms and build/test commands.
2. Inspect project structure, entry scenes/maps, gameplay systems, rendering/material setup and dependencies.
3. Identify concrete risks with file paths and evidence.
4. Prioritize findings as Blocker / High / Medium / Low.
5. Propose a staged vertical-slice improvement plan with measurable acceptance criteria.
6. Do not modify files during this audit unless the user explicitly asks for fixes.

Use the `architecture_blueprint` and `visual_fidelity_plan` MCP tools where useful.
