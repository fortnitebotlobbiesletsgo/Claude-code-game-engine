export const palettes = {
  neonNoir: {
    name: "Neon Noir",
    colors: { ink: "#080B12", surface: "#151B28", cyan: "#49E6F2", magenta: "#FF4FA3", amber: "#FFC857", text: "#EAF2F5" }
  },
  groundedCinematic: {
    name: "Grounded Cinematic",
    colors: { shadow: "#171B1C", midtone: "#59645E", highlight: "#D9D2BC", accent: "#B66A45", atmosphere: "#879B9B" }
  },
  verdantFantasy: {
    name: "Verdant Fantasy",
    colors: { deep: "#102B26", foliage: "#477B55", moss: "#A5A66A", gold: "#E2BD70", mist: "#C9D8C9" }
  }
} as const;

export const lightingProfiles = {
  cinematicExterior: {
    intent: "Readable cinematic exterior with motivated key light and controlled atmospheric depth.",
    layers: ["directional key", "sky or ambient fill", "motivated practicals", "subtle volumetric depth", " restrained color grade"],
    cautions: ["preserve shadow detail", "avoid clipping emissive signage", "profile volumetrics on target hardware"]
  },
  stylizedNight: {
    intent: "Stylized night scene with distinct pools of light and strong value hierarchy.",
    layers: ["cool ambient base", "warm practical pools", "selective emissive accents", "light atmospheric separation"],
    cautions: ["keep navigation readable", "avoid uniform neon saturation", "limit bloom radius"]
  }
} as const;

export const shaderPrinciples = {
  pbr: "Use physically based material inputs where supported: base color, roughness, metallic, normal, and ambient occlusion. Keep values within plausible ranges unless stylization is intentional.",
  stylized: "Use a controlled ramp or quantized diffuse response, consistent rim-light direction, and art-directed shadow colors. Preserve readable gradients at gameplay distance."
} as const;
