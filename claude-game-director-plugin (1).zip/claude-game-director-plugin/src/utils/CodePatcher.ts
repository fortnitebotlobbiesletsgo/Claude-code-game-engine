/**
 * Conservative text patch helper. It refuses ambiguous or repeated matches.
 * It does not execute code, access the filesystem, or silently overwrite files.
 */
export function replaceUnique(source: string, before: string, after: string): string {
  if (!before) throw new Error("Patch search text must not be empty.");
  const first = source.indexOf(before);
  if (first < 0) throw new Error("Patch target was not found.");
  if (source.indexOf(before, first + before.length) >= 0) {
    throw new Error("Patch target is ambiguous: search text occurs more than once.");
  }
  return source.slice(0, first) + after + source.slice(first + before.length);
}

export function appendWithMarker(source: string, marker: string, content: string): string {
  if (!marker.trim()) throw new Error("Marker must not be empty.");
  if (source.includes(marker)) throw new Error(`Marker already exists: ${marker}`);
  return `${source.replace(/\s*$/, "")}\n\n${marker}\n${content.trim()}\n`;
}
