// @ts-nocheck
// Source for the dependency-free MCP stdio entrypoint in ../dist/index.js.
#!/usr/bin/env node
/**
 * Minimal MCP stdio server (JSON-RPC 2.0), dependency-free.
 * Implements initialize, notifications/initialized, tools/list, tools/call and ping.
 * Logs only to stderr; stdout is reserved for MCP protocol messages.
 */
import readline from "node:readline";

const VERSION = "2024-11-05";
const tools = [
  {
    name: "visual_fidelity_plan",
    description: "Create a practical engine-aware art direction, lighting, palette, quality tier and validation plan.",
    inputSchema: {
      type: "object",
      properties: {
        engine: { type: "string", enum: ["unreal", "godot", "unity", "webgl"] },
        target: { type: "string", minLength: 3 },
        artDirection: { type: "string" },
        quality: { type: "string", enum: ["performance", "balanced", "cinematic"], default: "balanced" }
      },
      required: ["engine", "target"]
    }
  },
  {
    name: "shader_implementation_brief",
    description: "Create a shader implementation brief with engine and renderer constraints.",
    inputSchema: {
      type: "object",
      properties: {
        engine: { type: "string", enum: ["unreal", "godot", "unity", "webgl"] },
        effect: { type: "string", enum: ["dissolve", "toon", "emissive", "water"] },
        description: { type: "string", minLength: 5 }
      },
      required: ["engine", "effect", "description"]
    }
  },
  {
    name: "game_feel_plan",
    description: "Plan input responsiveness, anticipation, action, impact, recovery, accessibility and tuning.",
    inputSchema: {
      type: "object",
      properties: {
        mechanic: { type: "string", minLength: 3 },
        genre: { type: "string", default: "action adventure" },
        intensity: { type: "string", enum: ["subtle", "expressive", "high-impact"], default: "expressive" }
      },
      required: ["mechanic"]
    }
  },
  {
    name: "architecture_blueprint",
    description: "Propose modular game architecture and a repository layout for the selected engine and scope.",
    inputSchema: {
      type: "object",
      properties: {
        engine: { type: "string", enum: ["unreal", "godot", "unity", "webgl"] },
        project: { type: "string", minLength: 2 },
        genre: { type: "string", minLength: 2 },
        scope: { type: "string", enum: ["prototype", "indie", "large-scale"], default: "indie" }
      },
      required: ["engine", "project", "genre"]
    }
  },
  {
    name: "engine_capabilities",
    description: "Describe supported engine families and their practical constraints.",
    inputSchema: { type: "object", properties: { engine: { type: "string", enum: ["unreal", "godot", "unity", "webgl"] } } }
  }
];

const engine = {
  unreal: {
    label: "Unreal Engine 5.x",
    points: ["Use Lumen only when platform and frame-time budgets support it.", "Use Niagara for scalable, parameterized effects.", "Use C++ for core/performance-sensitive systems and Blueprints for designer-facing orchestration.", "Profile with Unreal Insights, stat unit and stat gpu."]
  },
  godot: {
    label: "Godot 4.x",
    points: ["Compose systems from focused scenes and scripts.", "Use typed GDScript or C# consistently.", "Use RenderingServer only when higher-level APIs are insufficient.", "Profile shader overdraw and use MultiMesh for repeated geometry."]
  },
  unity: {
    label: "Unity 2022 LTS / Unity 6",
    points: ["Choose URP for broad scalability or HDRP for supported high-end targets.", "Use ScriptableObjects for authored data.", "Use Shader Graph or pipeline-compatible HLSL.", "Profile with Profiler, Frame Debugger and Memory Profiler."]
  },
  webgl: {
    label: "WebGL 2 / Three.js / Babylon.js",
    points: ["Treat GPU capability and device pixel ratio as budgets.", "Use instancing, batching and compressed textures.", "Dispose GPU resources and handle context loss.", "Test on representative browsers and integrated GPUs."]
  }
};
const palettes = {
  neonNoir: { ink:"#080B12", surface:"#151B28", cyan:"#49E6F2", magenta:"#FF4FA3", amber:"#FFC857", text:"#EAF2F5" },
  groundedCinematic: { shadow:"#171B1C", midtone:"#59645E", highlight:"#D9D2BC", accent:"#B66A45" },
  verdantFantasy: { deep:"#102B26", foliage:"#477B55", moss:"#A5A66A", gold:"#E2BD70", mist:"#C9D8C9" }
};
function need(v, key) { if (typeof v !== "string" || !v.trim()) throw Error(`${key} is required`); return v.trim(); }
function engineFor(v) { const e=engine[v]; if(!e) throw Error("engine must be unreal, godot, unity, or webgl"); return e; }
function plan(name, lines) { return `# ${name}\n\n${lines.join("\n")}`; }
function runTool(name, a={}) {
  if (name === "engine_capabilities") {
    if (a.engine) return engineFor(a.engine).label + "\n" + engineFor(a.engine).points.map(x=>"- "+x).join("\n");
    return Object.entries(engine).map(([k,v])=>`${k}: ${v.label}\n${v.points.map(x=>"- "+x).join("\n")}`).join("\n\n");
  }
  if (name === "visual_fidelity_plan") {
    const e=engineFor(a.engine), target=need(a.target,"target"), quality=a.quality||"balanced";
    if (!["performance","balanced","cinematic"].includes(quality)) throw Error("invalid quality");
    const q={performance:"Prioritize stable frame time, overdraw control, scalable effects and low-cost lighting.",balanced:"Use scalable tiers; reserve expensive effects for high-value visible areas.",cinematic:"Raise lighting and material fidelity selectively, then validate against target frame-time budgets."}[quality];
    return plan(`Visual fidelity plan: ${target}`,[
      `Engine: ${e.label}`,`Art direction: ${a.artDirection||"Define palette, silhouette language, material response and camera framing."}`,`Quality: ${quality} — ${q}`,
      `Palette reference (Neon Noir): ${JSON.stringify(palettes.neonNoir)}`,"",
      "## Lighting stack","- Motivated key light","- Ambient/sky fill","- Practical lights","- Atmospheric separation","- Restrained post-processing",
      "## Engine guidance",...e.points.map(x=>"- "+x),
      "## Acceptance checks","- Review a representative gameplay frame at native camera distance.","- Preserve silhouette and gameplay readability.","- Profile CPU/GPU frame time on minimum-spec hardware.","- Validate low, medium and high scalability paths."
    ]);
  }
  if (name === "shader_implementation_brief") {
    const e=engineFor(a.engine), effect=need(a.effect,"effect"), desc=need(a.description,"description");
    const routes={unreal:"Material Editor / Custom HLSL node; expose Material Instance parameters.",godot:"Godot 4 spatial shader with declared uniforms and only the required shader stages.",unity:"Shader Graph or pipeline-compatible HLSL; state URP/HDRP explicitly.",webgl:"Three.js ShaderMaterial or Babylon.js custom material with WebGL2 precision declarations."};
    const detail={dissolve:"Expose amount, edge width/color and stable noise source.",toon:"Use an art-directed diffuse ramp, shadow tint and optional rim response.",emissive:"Separate emissive color/intensity from base color; avoid bloom washout.",water:"Define depth tint, roughness, animated normals, Fresnel and shoreline treatment."};
    if(!detail[effect]) throw Error("effect must be dissolve, toon, emissive, or water");
    return plan(`Shader brief: ${effect}`,[`Engine: ${e.label}`,`Request: ${desc}`,`Implementation: ${routes[a.engine]}`,detail[effect],"## Exposed parameters","- Effect intensity/blend","- Primary and secondary colors","- Quality toggle for expensive paths","## Acceptance criteria","- Compile against the exact engine version and renderer.","- Document parameters and safe defaults.","- Include a preview scene/material and profiling notes.","- Do not assume unspecified plugins or asset paths."]);
  }
  if (name === "game_feel_plan") {
    const mechanic=need(a.mechanic,"mechanic"), intensity=a.intensity||"expressive";
    const tone={subtle:"Short restrained feedback, minimal camera movement and grounded timing.",expressive:"Layer animation, audio, particles and modest camera response.", "high-impact":"Stronger anticipation and impact accents, with configurable intensity and clear readability."}[intensity];
    if(!tone) throw Error("invalid intensity");
    return plan(`Game feel plan: ${mechanic}`,[`Genre: ${a.genre||"action adventure"}`,tone,"## Feedback sequence","1. Anticipation: communicate intent.","2. Input response: acknowledge input immediately.","3. Action: tune animation curves and timing to the mechanic's weight.","4. Impact: coordinate audio, VFX, animation, UI and optional camera response.","5. Recovery: restore control and communicate the new state.","## Validation","- Tune input buffering and cancel rules.","- Test at low and high frame rates.","- Make shake/flashes adjustable and provide reduced-motion alternatives.","- Never obscure hazards, aiming, subtitles or critical UI."]);
  }
  if (name === "architecture_blueprint") {
    const e=engineFor(a.engine), project=need(a.project,"project"), genre=need(a.genre,"genre"), scope=a.scope||"indie";
    if(!["prototype","indie","large-scale"].includes(scope)) throw Error("invalid scope");
    return plan(`Architecture: ${project}`,[`Engine: ${e.label}`,`Genre: ${genre}`,`Scope: ${scope}`,"## Boundaries","- Domain: rules, state transitions, inventory, progression","- Application: use cases and orchestration","- Engine adapter: input, scenes/actors, animation, audio, rendering","- Infrastructure: persistence, telemetry, platform services, networking","- Content: data assets, tuning, localization and levels","## Engine-specific notes",...e.points.map(x=>"- "+x),"## Delivery gates","- Prototype: prove core loop in one vertical slice.","- Production: tests, save compatibility, content validation and profiling budgets.","- Release: platform compliance, accessibility, crash recovery and minimum-spec performance.","Start small; add abstractions only when a real use case justifies them."]);
  }
  throw Error(`Unknown tool: ${name}`);
}
function send(msg) { process.stdout.write(JSON.stringify(msg)+"\n"); }
function response(id, result) { send({jsonrpc:"2.0",id,result}); }
function error(id, code, message) { send({jsonrpc:"2.0",id,error:{code,message}}); }
const rl=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
rl.on("line", line => {
  let msg;
  try { msg=JSON.parse(line); } catch { return; }
  if (!msg || msg.jsonrpc!=="2.0" || !("method" in msg)) return;
  const id=msg.id;
  try {
    switch(msg.method) {
      case "initialize":
        response(id,{protocolVersion:VERSION,capabilities:{tools:{}},serverInfo:{name:"claude-game-director",version:"1.0.0"}});
        break;
      case "notifications/initialized":
      case "notifications/cancelled":
        break;
      case "ping":
        response(id,{});
        break;
      case "tools/list":
        response(id,{tools});
        break;
      case "tools/call": {
        const name=msg.params?.name, args=msg.params?.arguments||{};
        try { response(id,{content:[{type:"text",text:runTool(name,args)}]}); }
        catch(e) { response(id,{content:[{type:"text",text:e instanceof Error?e.message:String(e)}],isError:true}); }
        break;
      }
      default:
        if(id!==undefined) error(id,-32601,`Method not found: ${msg.method}`);
    }
  } catch(e) {
    if(id!==undefined) error(id,-32603,e instanceof Error?e.message:"Internal error");
  }
});
