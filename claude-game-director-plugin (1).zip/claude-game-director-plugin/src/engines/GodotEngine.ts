export const GodotEngine = {
  id: "godot",
  versions: "Godot 4.x (verify exact minor version)",
  guidance: [
    "Use scenes as composition units and keep scripts focused on one responsibility.",
    "Use RenderingServer or lower-level servers only when scene-level APIs are insufficient.",
    "Use typed GDScript or C# consistently; avoid mixing styles without a clear boundary.",
    "Use MultiMeshInstance3D for large repeated geometry and profile shader overdraw on mobile.",
    "Use resource-driven configuration and explicit signal contracts."
  ],
  starterFiles: ["scenes/", "scripts/", "shaders/", "resources/", "tests/"]
} as const;
