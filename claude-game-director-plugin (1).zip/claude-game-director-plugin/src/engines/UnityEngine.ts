export const UnityEngine = {
  id: "unity",
  versions: "Unity 2022 LTS / Unity 6 (verify project version)",
  guidance: [
    "Choose URP for broad scalability or HDRP for supported high-end targets; do not mix pipeline-specific assets.",
    "Use ScriptableObjects for authored configuration and data-driven tuning.",
    "Use Shader Graph for maintainable authored shaders; use HLSL for specialized or performance-sensitive work.",
    "Use the Profiler, Frame Debugger, Memory Profiler, and platform captures.",
    "Keep MonoBehaviour lifecycle code thin and move reusable logic into plain C# services where appropriate."
  ],
  starterFiles: ["Assets/Scripts/", "Assets/Art/Materials/", "Assets/VFX/", "Assets/Tests/"]
} as const;
