export const UnrealEngine = {
  id: "unreal",
  versions: "Unreal Engine 5.x (verify exact minor version)",
  guidance: [
    "Use Lumen only when target hardware and platform support the required quality/performance profile.",
    "Use Niagara for scalable, parameterized effects; expose user parameters and scalability controls.",
    "Prefer C++ for core systems and performance-critical logic; use Blueprints for orchestration and designer iteration.",
    "Use World Partition and data layers for large worlds when the project scale justifies them.",
    "Profile with Unreal Insights, stat unit, stat gpu, and platform-specific captures."
  ],
  starterFiles: ["Source/<Project>/", "Content/Blueprints/", "Content/Materials/", "Content/VFX/"]
} as const;
