export const WebGLEngine = {
  id: "webgl",
  versions: "WebGL 2 / Three.js / Babylon.js (pin library versions)",
  guidance: [
    "Treat GPU capability, device pixel ratio, shader precision, and context loss as first-class constraints.",
    "Use instancing, batching, compressed textures, and conservative shadow budgets.",
    "Provide graceful fallbacks for unsupported extensions and lower-end devices.",
    "Dispose GPU resources deterministically and handle WebGL context-restoration events.",
    "Measure frame time on representative browsers and integrated GPUs."
  ],
  starterFiles: ["src/rendering/", "src/scenes/", "src/materials/", "public/assets/"]
} as const;
