import { z } from "zod";

export const shaderInput = z.object({
  engine: z.enum(["unreal", "godot", "unity", "webgl"]),
  effect: z.enum(["dissolve", "toon", "emissive", "water"]),
  description: z.string().min(5).max(1000)
});

export function buildShaderBrief(input: z.infer<typeof shaderInput>): string {
  const notes: Record<string, string> = {
    dissolve: "Expose dissolve amount, edge width, edge color, and a stable noise source. Keep the transition deterministic when gameplay synchronization matters.",
    toon: "Use an art-directed diffuse ramp, controlled shadow tint, optional rim light, and consistent light direction. Test at the final camera distance.",
    emissive: "Separate emissive color/intensity from base color. Prevent bloom from washing out adjacent UI or silhouettes.",
    water: "Define depth tint, roughness, normal motion, Fresnel response, and shoreline treatment. Avoid expensive refraction on unsupported targets."
  };
  const syntax: Record<string, string> = {
    unreal: "Material Editor / Custom HLSL node; use material instances for exposed parameters.",
    godot: "Godot 4 spatial shader; declare uniforms and implement fragment/light stages as required.",
    unity: "Shader Graph for authored graph workflows, or URP/HDRP-compatible HLSL with explicit pipeline assumptions.",
    webgl: "Three.js ShaderMaterial or Babylon.js custom material; include precision declarations and WebGL2 assumptions."
  };
  return [
    `# Shader implementation brief: ${input.effect}`,
    `Engine: ${input.engine}`,
    `Requested effect: ${input.description}`,
    `Implementation route: ${syntax[input.engine]}`,
    `Design requirements: ${notes[input.effect]}`,
    "## Required exposed parameters",
    "- effect intensity / blend",
    "- primary color",
    "- secondary color or edge tint (where relevant)",
    "- quality/performance toggle when the effect has a costly path",
    "## Acceptance criteria",
    "- Compiles in the stated engine version and render pipeline.",
    "- Parameters are documented and have safe defaults.",
    "- No hidden dependency on an unspecified plugin or asset.",
    "- Includes a small test scene/material preview and target-hardware profiling notes.",
    "",
    "This tool returns an implementation brief, not unverified engine-specific shader source. Supply the exact engine minor version and render pipeline before generating compile-ready shader code."
  ].join("\n");
}
