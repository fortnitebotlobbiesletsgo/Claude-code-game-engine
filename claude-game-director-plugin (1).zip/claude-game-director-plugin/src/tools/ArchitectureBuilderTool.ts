import { z } from "zod";
import { UnrealEngine } from "../engines/UnrealEngine.js";
import { GodotEngine } from "../engines/GodotEngine.js";
import { UnityEngine } from "../engines/UnityEngine.js";
import { WebGLEngine } from "../engines/WebGLEngine.js";

export const architectureInput = z.object({
  engine: z.enum(["unreal", "godot", "unity", "webgl"]),
  project: z.string().min(2).max(120),
  genre: z.string().min(2).max(100),
  scope: z.enum(["prototype", "indie", "large-scale"]).default("indie")
});

export function buildArchitecture(input: z.infer<typeof architectureInput>): string {
  const engine = ({ unreal: UnrealEngine, godot: GodotEngine, unity: UnityEngine, webgl: WebGLEngine })[input.engine];
  const layers = [
    "Game domain: rules, state transitions, scoring, inventory, progression",
    "Application: orchestration, use cases, save/load coordination",
    "Engine adapter: input, scenes/actors, animation, audio, rendering",
    "Infrastructure: persistence, telemetry, platform services, networking",
    "Content: data assets, tuning tables, localization, authored levels"
  ];
  return [
    `# Architecture proposal: ${input.project}`,
    `Engine: ${engine.versions}`,
    `Genre: ${input.genre}`,
    `Scope: ${input.scope}`,
    "",
    "## Suggested boundaries",
    ...layers.map((x, i) => `${i + 1}. ${x}`),
    "",
    "## Engine conventions",
    ...engine.guidance.map(x => `- ${x}`),
    "",
    "## Suggested repository layout",
    ...engine.starterFiles.map(x => `- ${x}`),
    "- docs/architecture/",
    "- tests/unit/",
    "- tests/integration/",
    "",
    "## Delivery gates",
    "- Prototype: prove the core loop and one representative vertical slice.",
    "- Production: add automated tests, save compatibility, profiling budgets, and content validation.",
    "- Release: validate platform compliance, crash recovery, accessibility, and performance on minimum-spec hardware.",
    "",
    "Keep the initial implementation smaller than the final architecture. Add abstractions only when a real use case or test boundary justifies them."
  ].join("\n");
}
