import { z } from "zod";

export const gameFeelInput = z.object({
  mechanic: z.string().min(3).max(300),
  genre: z.string().min(2).max(100).default("action adventure"),
  intensity: z.enum(["subtle", "expressive", "high-impact"]).default("expressive")
});

export function buildGameFeelPlan(input: z.infer<typeof gameFeelInput>): string {
  const intensity = {
    subtle: "Short, restrained feedback; minimal camera motion; preserve a grounded tone.",
    expressive: "Layer animation, audio, particles, and modest camera response with clear timing.",
    "high-impact": "Use stronger anticipation and impact accents, but keep effects configurable and never obscure gameplay-critical information."
  }[input.intensity];
  return [
    `# Game-feel plan: ${input.mechanic}`,
    `Genre: ${input.genre}`,
    `Intensity: ${input.intensity}`,
    intensity,
    "",
    "## Feedback sequence",
    "1. Anticipation: communicate intent before the action resolves.",
    "2. Input response: acknowledge input immediately; avoid unnecessary animation lockout.",
    "3. Action: use animation curves and timing that support the mechanic's weight.",
    "4. Impact: coordinate audio, VFX, animation, UI, and optional camera feedback.",
    "5. Recovery: return control cleanly and communicate the new gameplay state.",
    "",
    "## Tuning checklist",
    "- Input buffering and coyote/forgiveness windows where appropriate.",
    "- Animation cancel rules and transition conditions.",
    "- Sound variation without excessive randomness.",
    "- Camera shake, flashes, and hit-stop have user-adjustable intensity or reduced-motion alternatives.",
    "- Effects do not obscure hazards, aiming, subtitles, or critical UI.",
    "- Validate at low and high frame rates and with accessibility settings."
  ].join("\n");
}
