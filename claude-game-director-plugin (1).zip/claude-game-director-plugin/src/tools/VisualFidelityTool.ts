import { z } from "zod";
import { lightingProfiles, palettes } from "../config/presets.js";
import { UnrealEngine } from "../engines/UnrealEngine.js";
import { GodotEngine } from "../engines/GodotEngine.js";
import { UnityEngine } from "../engines/UnityEngine.js";
import { WebGLEngine } from "../engines/WebGLEngine.js";

export const visualFidelityInput = z.object({
  engine: z.enum(["unreal", "godot", "unity", "webgl"]),
  target: z.string().min(3).max(500),
  artDirection: z.string().min(3).max(1000).optional(),
  quality: z.enum(["performance", "balanced", "cinematic"]).default("balanced")
});

export function buildVisualFidelityPlan(input: z.infer<typeof visualFidelityInput>): string {
  const engine = ({ unreal: UnrealEngine, godot: GodotEngine, unity: UnityEngine, webgl: WebGLEngine })[input.engine];
  const qualityNotes = {
    performance: "Prioritize stable frame time, overdraw control, scalable effects, and lower-cost lighting.",
    balanced: "Use scalable quality tiers and reserve expensive effects for visible, high-value areas.",
    cinematic: "Increase lighting/material fidelity selectively, then validate against the target platform's frame-time budget."
  };
  const palette = palettes.neonNoir;
  const lighting = lightingProfiles.cinematicExterior;
  return [
    `# Visual fidelity plan: ${input.target}`,
    `Engine: ${engine.id} (${engine.versions})`,
    `Quality target: ${input.quality}`,
    `Art direction: ${input.artDirection ?? "Define palette, silhouette language, material response, and camera framing before asset production."}`,
    "",
    `## Quality strategy\n${qualityNotes[input.quality]}`,
    `## Palette reference: ${palette.name}\n${JSON.stringify(palette.colors, null, 2)}`,
    `## Lighting profile: ${lighting.intent}\n${lighting.layers.map(x => `- ${x}`).join("\n")}`,
    `## Engine-specific guidance\n${engine.guidance.map(x => `- ${x}`).join("\n")}`,
    "## Validation\n- Capture a representative gameplay frame.\n- Check silhouette and focal hierarchy at native gameplay camera distance.\n- Profile GPU/CPU frame time on target hardware.\n- Verify low/medium/high scalability paths."
  ].join("\n");
}
